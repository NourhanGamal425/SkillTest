
function CardCalculate(x1,x2,x3,x4,type)
{
    let sum=(+x1+ +x2+ +x3+ +x4);
    
    var progress1  = document.getElementById("progress1");
    progress1.hidden=false;
    var h5Generate  = document.getElementById("h5Generate");
    h5Generate.innerHTML=`<h5>`+type+`Business Card</h5>`
    

    var txtUnlimited = document.getElementById("txtunlimited");    
    txtUnlimited.innerHTML= "$"+(sum*1.1).toFixed(0);
    var txtLifetime  = document.getElementById("txtLifetime");
    txtLifetime.innerHTML="$"+(sum*1.2).toFixed(0);

    var result = document.getElementById("txtresult");
    if(type=="Brex")
    {
        result.innerHTML="$"+(sum*0.3).toFixed(0);
    }
    else if (type=="Stripe")
    {
        result.innerHTML="$"+(sum*2.9).toFixed(0);
    }
    else if (type=="Amex")
    {
        result.innerHTML="$"+(sum*1.3).toFixed(0);
    }

}